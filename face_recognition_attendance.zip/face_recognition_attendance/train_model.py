import os
import numpy as np
from PIL import Image
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout
from tensorflow.keras.optimizers import Adam
import pickle

def load_dataset():
    dataset_path = "dataset"
    faces = []
    labels = []
    
    for person_name in os.listdir(dataset_path):
        person_path = os.path.join(dataset_path, person_name)
        
        if os.path.isdir(person_path):
            for image_name in os.listdir(person_path):
                image_path = os.path.join(person_path, image_name)
                
                try:
                    img = Image.open(image_path).convert('RGB')
                    img = img.resize((160, 160))
                    img_array = np.array(img)
                    faces.append(img_array)
                    labels.append(person_name)
                except Exception as e:
                    print(f"Error loading {image_path}: {e}")
    
    return np.array(faces), np.array(labels)

def create_model(input_shape, num_classes):
    model = Sequential([
        Conv2D(32, (3, 3), activation='relu', input_shape=input_shape),
        MaxPooling2D((2, 2)),
        Conv2D(64, (3, 3), activation='relu'),
        MaxPooling2D((2, 2)),
        Conv2D(128, (3, 3), activation='relu'),
        MaxPooling2D((2, 2)),
        Flatten(),
        Dense(256, activation='relu'),
        Dropout(0.5),
        Dense(num_classes, activation='softmax')
    ])
    
    model.compile(optimizer=Adam(learning_rate=0.001),
                  loss='categorical_crossentropy',
                  metrics=['accuracy'])
    
    return model

def train_model():
    # Load dataset
    faces, labels = load_dataset()
    
    if len(faces) == 0:
        print("No faces found in dataset. Please register faces first.")
        return
    
    # Preprocess data
    faces = faces.astype('float32') / 255.0
    
    # Encode labels
    label_encoder = LabelEncoder()
    labels_encoded = label_encoder.fit_transform(labels)
    labels_onehot = to_categorical(labels_encoded)
    
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        faces, labels_onehot, test_size=0.2, random_state=42)
    
    # Create model
    input_shape = (160, 160, 3)
    num_classes = len(label_encoder.classes_)
    model = create_model(input_shape, num_classes)
    
    # Train model
    model.fit(X_train, y_train,
              epochs=20,
              batch_size=32,
              validation_data=(X_test, y_test))
    
    # Save model
    model_json = model.to_json()
    with open("models/face_recognizer.json", "w") as json_file:
        json_file.write(model_json)
    model.save_weights("models/face_recognizer.h5")
    print("Model saved to disk")
    
    # Save label encoder
    with open("encodings/encodings.pickle", "wb") as f:
        pickle.dump(label_encoder, f)
    
    print("Training complete")

if __name__ == "__main__":
    # Create necessary directories
    os.makedirs("models", exist_ok=True)
    os.makedirs("encodings", exist_ok=True)
    
    train_model()