import cv2
import numpy as np
from tensorflow.keras.models import model_from_json
from tensorflow.keras.preprocessing.image import img_to_array
import pickle
import pandas as pd
import os
from datetime import datetime

def load_model():
    # Load model architecture
    with open("models/face_recognizer.json", "r") as json_file:
        loaded_model_json = json_file.read()
    model = model_from_json(loaded_model_json)
    
    # Load model weights
    model.load_weights("models/face_recognizer.h5")
    
    # Load label encoder
    with open("encodings/encodings.pickle", "rb") as f:
        label_encoder = pickle.load(f)
    
    return model, label_encoder

def mark_attendance(name):
    os.makedirs("attendance", exist_ok=True)
    attendance_file = "attendance/attendance.csv"
    
    # Get current date and time
    now = datetime.now()
    date_str = now.strftime("%Y-%m-%d")
    time_str = now.strftime("%H:%M:%S")
    
    # Create or load attendance file
    if os.path.exists(attendance_file):
        df = pd.read_csv(attendance_file)
    else:
        df = pd.DataFrame(columns=["Name", "Date", "Time"])
    
    # Check if attendance already marked today
    if not ((df['Name'] == name) & (df['Date'] == date_str)).any():
        new_entry = pd.DataFrame([[name, date_str, time_str]], 
                                columns=["Name", "Date", "Time"])
        df = pd.concat([df, new_entry], ignore_index=True)
        df.to_csv(attendance_file, index=False)
        print(f"Attendance marked for {name}")
    else:
        print(f"Attendance already marked for {name} today")

def recognize_faces():
    model, label_encoder = load_model()
    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
    cap = cv2.VideoCapture(0)
    
    last_recognition_time = 0
    recognition_interval = 5  # seconds
    
    while True:
        ret, frame = cap.read()
        if not ret:
            break
            
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = face_cascade.detectMultiScale(gray, 1.3, 5)
        
        current_time = datetime.now().timestamp()
        
        for (x, y, w, h) in faces:
            cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 0, 0), 2)
            
            # Recognize face at intervals
            if current_time - last_recognition_time > recognition_interval:
                face_roi = frame[y:y+h, x:x+w]
                face_roi = cv2.resize(face_roi, (160, 160))
                face_roi = img_to_array(face_roi)
                face_roi = face_roi.astype('float32') / 255.0
                face_roi = np.expand_dims(face_roi, axis=0)
                
                # Predict
                preds = model.predict(face_roi)[0]
                idx = np.argmax(preds)
                prob = preds[idx]
                name = label_encoder.classes_[idx]
                
                if prob > 0.8:  # Confidence threshold
                    cv2.putText(frame, f"{name} ({prob:.2f})", (x, y-10),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)
                    mark_attendance(name)
                    last_recognition_time = current_time
                else:
                    cv2.putText(frame, "Unknown", (x, y-10),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 0, 255), 2)
        
        cv2.imshow('Face Recognition Attendance', frame)
        
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    
    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    recognize_faces()